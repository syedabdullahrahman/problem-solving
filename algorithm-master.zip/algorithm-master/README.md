# C++ implementations of algorithms

These are my C++ implementations of algorithms,
which are written for studying/understanding algorithms.

These codes are published in **public domain.**
You can use the codes for *any purpose without any warranty*.


author: Takanori MAEHARA (web: http://www.prefield.com, e-mail: maehara@prefield.com, twitter: @tmaehara)
